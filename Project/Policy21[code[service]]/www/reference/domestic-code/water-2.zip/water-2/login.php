﻿<center>
<table class = "pert50">
	<tr>
		<td>訪問員編號:</td>
		<td><input type = "text" name = "eno" id = "eno"></td>
	</tr>
	<tr>
		<td>密碼:</td>
		<td><input type = "password" name = "pass" id = "pass"></td>
	</tr>
</table>
<input type = "submit" name = "sub" id = "sub" value = "登入" >
</center>