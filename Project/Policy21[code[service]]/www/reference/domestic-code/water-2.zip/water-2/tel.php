﻿電話：<input type = "text" name = "tel" id = "tel">
<input type = "submit" name = "sub2" id = "sub2" value = "搜尋">
<input type = "submit" name = "sub3" id = "sub3" value = "下一個">